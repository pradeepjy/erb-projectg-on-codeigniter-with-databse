<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lblock {

    //Block add form
    public function block_add_form() {
        $CI = & get_instance();
        $CI->load->model('Blocks');
        $data = array(
            'title' => display('Block')
        );
        $blockForm = $CI->parser->parse('block/create', $data, true);
        return $blockForm;
    }

    //Insert Block
    public function insert_block($data) {
        $CI = & get_instance();
        $CI->load->model('Blocks');
        $result = $CI->block->store($data);
        if ($result == TRUE) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    //Block List
    public function block_list() {
   
        $CI =& get_instance();
        $CI->load->model('Blocks');
        $data = array(
            'title' => display('block')
        );
        $data['block_list']    = $CI->blocks->block_list();
        $blocklist = $CI->parser->parse('block/index',$data,true);
        return $blocklist;
    }
    
    public function retrieve_block_editdata($block_id) {
        $CI = & get_instance();
        $CI->load->model('Blocks');
        $block_detail = $CI->blocks->block_editdata($block_id);
        $data = array(
            'title' => display('block_edit'),
            'id'=> $block_detail[0]['id'],
            'block_code'=> $block_detail[0]['block_code'],
            'block_id' => $block_detail[0]['block_id'],
            'manufacturing_date' => $block_detail[0]['manufacturing_date'],
            'total_expense' => $block_detail[0]['total_expense'],
            'block_failed'=> $block_detail[0]['block_failed'],
            'block_left' => $block_detail[0]['block_left'],
            'block_sale' => $block_detail[0]['block_sale'],
            'status' => $block_detail[0]['status']
        );
        $blockList = $CI->parser->parse('block/edit', $data, true);
        return $blockList;
    }

   
}
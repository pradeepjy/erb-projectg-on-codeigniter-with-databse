<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lwall {

    //Wall add form
    public function wall_add_form() {
        $CI = & get_instance();
        $CI->load->model('walls');
        $data = array(
            'title' => display('wall')
        );
        $wallForm = $CI->parser->parse('wall/create', $data, true);
        return $wallForm;
    }

    //Insert wall
    public function insert_wall($data) {
        $CI = & get_instance();
        $CI->load->model('Walls');
        $result = $CI->Wall->store($data);
        if ($result == TRUE) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    //Wall List
    public function wall_list() {
   
        $CI =& get_instance();
        $CI->load->model('Walls');
        $data = array(
            'title' => display('manage_wall')
        );
        $data['wall_list']    = $CI->Walls->wall_list();
        $wall_list = $CI->parser->parse('wall/index',$data,true);
        return $wall_list;
    }
    
    public function retrieve_wall_editdata($wall_id) {
        $CI = & get_instance();
        $CI->load->model('Walls');
        $wall_detail = $CI->Walls->wall_editdata($wall_id);
        $data = array(
            'title' => display('wall_edit'),
            'id'=> $wall_detail[0]['id'],
            'wall_code'=> $wall_detail[0]['wall_code'],
            'wall_id' => $wall_detail[0]['wall_id'],
            'manufacturing_date' => $wall_detail[0]['manufacturing_date'],
            'total_expense' => $wall_detail[0]['total_expense'],
            'number_of_block' => $wall_detail[0]['number_of_block'],
            'block_failed'=> $wall_detail[0]['block_failed'],
            'block_left' => $wall_detail[0]['block_left'],
            'status' => $wall_detail[0]['status']
        );
        $wallList = $CI->parser->parse('wall/edit', $data, true);
        return $wallList;
    }

   
}
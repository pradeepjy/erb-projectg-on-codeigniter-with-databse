<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Lproduction_flow {

    //production_flow add form
    public function production_flow_add_form() {
        $CI = & get_instance();
        $CI->load->model('production_flows');
        $data = array(
            'title' => display('production_flow')
        );
        $production_flowForm = $CI->parser->parse('production_flow/create', $data, true);
        return $production_flowForm;
    }

    //Insert production_flow
    public function insert_production_flow($data) {
        $CI = & get_instance();
        $CI->load->model('production_flows');
        $result = $CI->production_flow->store($data);
        if ($result == TRUE) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    //production_flow List
    public function production_flow_list() {
   
        $CI =& get_instance();
        $CI->load->model('production_flows');
        $data = array(
            'title' => display('production_flow')
        );
        $data['production_flow_list']    = $CI->production_flows->production_flow_list();
        $production_flowlist = $CI->parser->parse('production_flow/index',$data,true);
        return $production_flowlist;
    }
    
    public function retrieve_production_flow_editdata($production_flow_id) {
        $CI = & get_instance();
        $CI->load->model('production_flows');
        $production_flow_detail = $CI->production_flows->production_flow_editdata($production_flow_id);
        $data = array(
            'title' => display('production_flow_edit'),
            'id'=> $production_flow_detail[0]['id'],
            'work_start_date'=> $production_flow_detail[0]['work_start_date'],
            'work_end_date' => $production_flow_detail[0]['work_end_date'],
            'wastage' => $production_flow_detail[0]['wastage'],
            'total_expense' => $production_flow_detail[0]['total_expense'],
            'machine_used'=> $production_flow_detail[0]['machine_used'],
            'queries_that_raised' => $production_flow_detail[0]['queries_that_raised'],
            'status' => $production_flow_detail[0]['status']
        );
        $production_flowList = $CI->parser->parse('production_flow/edit', $data, true);
        return $production_flowList;
    }

   
}
<?php
$CI = & get_instance();
$CI->load->model('Web_settings');
$CI->load->model('Reports');
$CI->load->model('Users');
$Web_settings = $CI->Web_settings->retrieve_setting_editdata();
$users = $CI->Users->profile_edit_data();
$out_of_stock = $CI->Reports->out_of_stock_count();

?>

<header class="main-header"> 
    <a href="<?php echo base_url() ?>" class="logo"> <!-- Logo -->
        <span class="logo-mini">
            <!--<b>A</b>BD-->
            <img src="<?php
            if (isset($Web_settings[0]['favicon'])) {
                echo html_escape($Web_settings[0]['favicon']);
            }
            ?>" alt="">
        </span>

        <span class="logo-lg">
            <b>Admin</b>
           
        </span>
    </a>
    <!-- Header Navbar -->


    <nav class="navbar navbar-static-top text-center">

        <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button"> <!-- Sidebar toggle button-->
            <span class="sr-only">Toggle navigation</span>

            <span class="pe-7s-keypad"></span>
        </a>

             
          <?php
          $urcolp = '0';
          if($this->uri->segment(2) =="gui_pos" ){
            $urcolp = "gui_pos";
          }
          if($this->uri->segment(2) =="pos_invoice" ){
            $urcolp = "pos_invoice";
          }

           if($this->uri->segment(2) != $urcolp ){

           if($this->permission1->method('new_invoice','create')->access()){
         

           ?>
           <a href="<?php echo base_url('Cinvoice')?>" class="btn btn-success btn-outline" style="display:none"><i class="fa fa-balance-scale"></i> <?php  echo display('invoice') ?></a>
     <?php }?>

     
        <?php if($this->permission1->method('customer_receive','create')->access()){ ?>
           <a href="<?php echo base_url('accounts/customer_receive')?>" class="btn btn-success btn-outline" style="display:none"><i class="fa fa-money"></i> <?php echo display('customer_receive')?></a>
       <?php } ?>
      
  <?php if($this->permission1->method('supplier_payment','create')->access()){ ?>
          <a href="<?php echo base_url('accounts/supplier_payment')?>" class="btn btn-success btn-outline" style="display:none"><i class="fa fa-money" aria-hidden="true"></i> <?php echo display('supplier_payment')?></a>
      <?php } ?>

<?php if($this->permission1->method('add_purchase','create')->access()){ ?>
          <a href="<?php echo base_url('Cpurchase')?>" class="btn btn-success btn-outline" style="display:none"><i class="ti-shopping-cart"></i> <?php echo display('purchase') ?></a>
 <?php }} ?>

        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <li class="dropdown notifications-menu">
                    <a href="<?php echo base_url('Creport/out_of_stock') ?>" >
                        <i class="pe-7s-attention" title="<?php echo display('out_of_stock') ?>"></i>
                        <span class="label label-danger"><?php echo html_escape($out_of_stock) ?></span>
                    </a>
                </li>
                <!-- settings -->
                <li class="dropdown dropdown-user">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="pe-7s-settings"></i></a>
                    <ul class="dropdown-menu">
                        <li><a href="<?php echo base_url('Admin_dashboard/edit_profile') ?>"><i class="pe-7s-users"></i><?php echo display('user_profile') ?></a></li>
                        <li><a href="<?php echo base_url('Admin_dashboard/change_password_form') ?>"><i class="pe-7s-settings"></i><?php echo display('change_password') ?></a></li>
                        <li><a href="<?php echo base_url('Admin_dashboard/logout') ?>"><i class="pe-7s-key"></i><?php echo display('logout') ?></a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
</header>

<aside class="main-sidebar">
    <!-- sidebar -->
    <div class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel text-center">
            <div class="image">
                <img src="<?php echo html_escape($users[0]['logo']) ?>" class="img-circle" alt="User Image">
            </div>
            <div class="info">
                <p><?php echo $this->session->userdata('user_name') ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> <?php echo display('online') ?></a>
            </div>
        </div>
        <!-- sidebar menu -->
        <ul class="sidebar-menu">

            <li class="<?php
            if ($this->uri->segment('1') == ("")) {
                echo "active";
            } else {
                echo " ";
            }
            ?>">
                <a href="<?php echo base_url() ?>"><i class="ti-dashboard"></i> <span><?php echo display('dashboard') ?></span>
                    <span class="pull-right-container">
                        <span class="label label-success pull-right"></span>
                    </span>
                </a>
            </li>
            <!-- Invoice menu start -->
            <!-- Software Settings menu start -->
              <?php if($this->permission1->method('manage_company','read')->access() ||$this->permission1->method('manage_company','create')->access() || $this->permission1->method('add_user','create')->access() || $this->permission1->method('manage_user','read')->access() || $this->permission1->method('add_language','create')->access() || $this->permission1->method('add_currency','create')->access() || $this->permission1->method('soft_setting','create')->access() || $this->permission1->method('add_role','create')->access() ||$this->permission1->method('role_list','read')->access() || $this->permission1->method('user_assign','create')->access() || $this->permission1->method('sms_configure','create')->access()){?>
            <li class="treeview <?php
            if ($this->uri->segment('1') == ("Company_setup") || $this->uri->segment('1') == ("User") || $this->uri->segment('1') == ("Cweb_setting") || $this->uri->segment('1') == ("Language") || $this->uri->segment('1') == ("Currency") || $this->uri->segment('1') == ("Permission")|| $this->uri->segment('1') == ("Csms") || $this->uri->segment('1') == ("Backup_restore")) {
                echo "active";
            } else {
                echo " ";
            }
            ?>">
                <a href="#">
                    <i class="ti-user"></i><span><?php echo display('User') ?></span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                <?php if($this->permission1->method('add_user','create')->access()){?>
                    <li class="treeview <?php if ($this->uri->segment('1') == ("User") && $this->uri->segment('2') == ("")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('User') ?>"><?php echo display('add_user') ?></a></li>
                <?php }?>
                <?php if($this->permission1->method('manage_user','read')->access()){?>
                    <li class="treeview <?php if ($this->uri->segment('2') == ("manage_user")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('User/manage_user') ?>"><?php echo display('manage_users') ?> </a></li>
                <?php }?>
         <!-- Role permission start -->
     <?php if($this->permission1->method('add_role','create')->access() ||$this->permission1->method('role_list','read')->access() || $this->permission1->method('user_assign','create')->access()){?>
         <li  class="treeview <?php
            if ($this->uri->segment('1') == ("Permission")) {
                echo "active";
            } else {
                echo " ";
            }
            ?>">
                <a href="#">
                    <i class="ti-key"></i> <span><?php echo display('role_permission') ?></span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($this->permission1->method('add_role','create')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("add_role")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('Permission/add_role')?>"><?php echo display('add_role') ?></a></li>
                    <?php }?>
                      <?php if($this->permission1->method('role_list','read')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("role_list")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('Permission/role_list')?>"><?php echo display('role_list') ?></a></li>
                    <?php }?>
                    <?php if($this->permission1->method('user_assign','create')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("user_assign")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('Permission/user_assign')?>"><?php echo display('user_assign_role')?></a></li>
                    <?php }?>
                    </ul>
                </li>
            <?php }?>
                <!-- Role permission End -->
                </ul>
            </li>
        <?php }?>
        
        <?php if($this->permission1->method('wall','read')->access() ||$this->permission1->method('wall','create')->access() || $this->permission1->method('add_wall','create')->access() || $this->permission1->method('wall','read')->access()){?>
           
            <li class="treeview <?php 
            if ($this->uri->segment('1') == ("wall") || $this->uri->segment('1') == ("block") || $this->uri->segment('1') == ("production_flow") ) {
                echo "active";
            } else {
                echo " ";
            }
            ?>">
                <a href="#">
                    <i class="ti-book"></i><span>Work</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                <?php if($this->permission1->method('add_wall','create')->access()){?>
                    <li class="treeview <?php if ($this->uri->segment('1') == ("wall") && $this->uri->segment('2') == ("create")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>">
                <?php }?>
             
         <!-- Role permission start -->
     <?php if($this->permission1->method('add_wall','create')->access() ||$this->permission1->method('wall','read')->access() || $this->permission1->method('add_wall','create')->access()){?>
         <li  class="treeview <?php
            if ($this->uri->segment('1') == ("wall")) {
                echo "active";
            } else {
                echo " ";
            }
            ?>">
                <a href="#">
                    <i class="ti-bar-chart"></i> <span>wall</span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($this->permission1->method('add_wall','create')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("create")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('wall/create')?>">Add Wall</a></li>
                    <?php }?>
                      <?php if($this->permission1->method('wall','read')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("index")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('wall/index')?>">Wall List</a></li>
                    <?php }?>
                  
                    </ul>
                </li>
            <?php }?>
                <!-- Role permission End -->
            <?php if($this->permission1->method('add_block','create')->access() ||$this->permission1->method('block','read')->access() || $this->permission1->method('add_block','create')->access()){?>
            <li  class="treeview <?php
            if ($this->uri->segment('1') == ("block")) {
                echo "active";
            } else {
                echo " ";
            }
            ?>">
                <a href="#">
                    <i class="ti-bar-chart"></i> <span>Block</span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($this->permission1->method('add_block','create')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("create")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('block/create')?>">Add Block</a></li>
                    <?php }?>
                      <?php if($this->permission1->method('block','read')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("index")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('block/index')?>">Block List</a></li>
                    <?php }?>
                  
                    </ul>
                </li>
            <?php }?>
            <?php if($this->permission1->method('add_production_flow','create')->access() ||$this->permission1->method('production_flow','read')->access() || $this->permission1->method('add_production_flow','create')->access()){?>
            <li  class="treeview <?php
            if ($this->uri->segment('1') == ("production_flow")) {
                echo "active";
            } else {
                echo " ";
            }
            ?>">
                <a href="#">
                    <i class="ti-bar-chart"></i> <span>Production Flow</span>
                    <span class="pull-right-container">
                    <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <?php if($this->permission1->method('add_production_flow','create')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("create")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('production_flow/create')?>">Add Production Flow</a></li>
                    <?php }?>
                      <?php if($this->permission1->method('production_flow','read')->access()){?>
                        <li class="treeview <?php if ($this->uri->segment('2') == ("index")){
                        echo "active";
                    } else {
                        echo " ";
                    }?>"><a href="<?php echo base_url('production_flow/index')?>">Production Flow List</a></li>
                    <?php }?>
                  
                    </ul>
                </li>
            <?php }?>
                </ul>
            </li>
        <?php }?>
            <!-- Software Settings menu end -->

        </ul>
    </div> <!-- /.sidebar -->
</aside>

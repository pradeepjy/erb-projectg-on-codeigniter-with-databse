<!-- Edit User start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('block_edit') ?></h1>
            <small><?php echo display('block_edit') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li class="active"><?php echo display('block_edit') ?></li>
            </ol>
        </div>
    </section>
    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>

        <!-- New user -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('block_edit') ?> </h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('block/update',array('class' => 'form-vertical','id'=>'validate' ))?>
                    <div class="panel-body">
                        <div class="form-group row">
                            <label for="block_code" class="col-sm-3 col-form-label">block Code<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="block_code" id="block_code" value="<?php echo $block_code?>" placeholder="block Code" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_id" class="col-sm-3 col-form-label">block Id<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="block_id" id="block_id" value="<?php echo $block_id?>" placeholder="block Id" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="manufacturing_date" class="col-sm-3 col-form-label">Manufacture Date</label>
                            <div class="col-sm-9">
                            <input type="text" class="datepicker form-control" name="manufacturing_date" value="<?php echo $manufacturing_date?>" placeholder="Manufacture Date" id="manufacturing_date">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="total_expense" class="col-sm-3 col-form-label">Total Expense<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="number" tabindex="1" class="form-control" name="total_expense" id="total_expense" value="<?php echo $total_expense?>" placeholder="Total Expense" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_failed" class="col-sm-3 col-form-label">Block Failed<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="block_failed" id="block_failed" value="<?php echo $block_failed?>" placeholder="Block Failed" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_left" class="col-sm-3 col-form-label">Block Left<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="block_left" id="block_left" value="<?php echo $block_left?>" placeholder="Block Left" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_sale" class="col-sm-3 col-form-label">Block Sale<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="block_sale" id="block_sale" value="<?php echo $block_sale?>" placeholder="Block Sale" required />
                            </div>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id?>" />
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-block" class="btn btn-success btn-large" name="add-block" value="<?php echo display('save_changes') ?>" tabindex="6"/>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Edit user end -->




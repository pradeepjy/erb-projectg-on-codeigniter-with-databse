<!-- Add User start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>block</h1>
            <small>Add New block</small>
            <ol class="breadcrumb">
                <li><a href="index.html"><i class="pe-7s-home"></i> Home</a></li>
                <li class="active">Add Block</li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>
        <div class="row">
            <div class="col-sm-12">
                <?php if($this->permission1->method('block','read')->access()){?>
                  <a href="<?php echo base_url('block/index')?>" class="btn btn-success m-b-5 m-r-2"><i class="ti-align-justify"></i>Block</a>
              <?php }?>
            </div>
        </div>
        <!-- New user -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('add_block') ?> </h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('Block/store',array('class' => 'form-vertical','id'=>'validate'))?>
                    <div class="panel-body">
                        <div class="form-group row">
                            <label for="block_code" class="col-sm-3 col-form-label">Block Code<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="block_code" id="block_code" placeholder="Block Code" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_id" class="col-sm-3 col-form-label">Block Id<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="block_id" id="block_id" placeholder="block Id" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="manufacturing_date" class="col-sm-3 col-form-label">Manufacture Date</label>
                            <div class="col-sm-6">
                            <input type="text" class="datepicker form-control" name="manufacturing_date" placeholder="Manufacture Date" id="manufacturing_date">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="total_expense" class="col-sm-3 col-form-label">Total Expense<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="number" tabindex="1" class="form-control" name="total_expense" id="total_expense" placeholder="Total Expense" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_failed" class="col-sm-3 col-form-label">Block Failed<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="number" tabindex="1" class="form-control" name="block_failed" id="block_failed" placeholder="Block Failed" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_left" class="col-sm-3 col-form-label">Block Left<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="number" tabindex="1" class="form-control" name="block_left" id="block_left" placeholder="Block Left" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="block_sale" class="col-sm-3 col-form-label">Block Sale<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="number" tabindex="1" class="form-control" name="block_sale" id="block_sale" placeholder="Block Sale" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-block" class="btn btn-primary btn-large" name="add-block" value="<?php echo display('save') ?>" tabindex="6"/>

								<input type="submit" value="<?php echo display('save_and_add_another') ?>e" name="add-block-another" class="btn btn-success" id="add-block-another" tabindex="7">
                            </div>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Edit user end -->




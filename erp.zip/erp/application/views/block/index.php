<!-- User List Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1>Manage Block</h1>
	        <small>Manage Block</small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li class="active">Manage Block</li>
	        </ol>
	    </div>
	</section>

	<section class="content">
		<!-- Alert Message -->
	    <?php
	        $message = $this->session->userdata('message');
	        if (isset($message)) {
	    ?>
	    <div class="alert alert-info alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('message');
	        }
	        $error_message = $this->session->userdata('error_message');
	        if (isset($error_message)) {
	    ?>
	    <div class="alert alert-danger alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $error_message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('error_message');
	        }
	    ?>

	     <div class="row">
            <div class="col-sm-12">
                  <?php if($this->permission1->method('add_block','create')->access()){?>
                  <a href="<?php echo base_url('block/create')?>" class="btn btn-success m-b-5 m-r-2"><i class="ti-plus"></i>Block </a>
              <?php }?>
            </div>
        </div>
		<!-- block List -->
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4><?php echo display('block_users') ?> </h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample3" class="table table-bordered table-striped table-hover">
		           				<thead>
									<tr>
										<th><?php echo display('sl') ?></th>
										<th>block Code</th>
										<th>block Id</th>
										<th>Manufacture Date</th>
										<th>Total Expense</th>
										<th>Block Failed</th>
										<th>Block Left</th>
										<th>Block Sale</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
                                
								if ($block_list) {
									foreach ($block_list as $block) {
								?>
									<tr>
										<td><?php echo $block["id"]?></td>
										<td><?php echo html_escape($block["block_code"])?></td>
										<td><?php echo html_escape($block["block_id"])?></td>
                                        <td><?php echo html_escape($block["manufacturing_date"])?></td>
                                        <td><?php echo html_escape($block["total_expense"])?></td>
										<td><?php echo html_escape($block["block_failed"])?></td>
										<td><?php echo html_escape($block["block_left"])?></td>
										<td><?php echo html_escape($block["block_sale"])?></td>
										<td>
											<center>
											<?php echo form_open()?>
												<a href="<?php echo base_url('block/edit/'.$block["id"]); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="<?php echo display('update') ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
												
												<a href="<?php echo base_url('block/delete/'.$block["id"])?>" class="btn btn-danger btn-sm"  data-toggle="tooltip" onclick="return confirm('Are you Sure ?')" data-placement="right" title="" data-original-title="<?php echo display('delete') ?> "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
												
											<?php echo form_close()?>
											</center>
										</td>
									</tr>
								<?php } } ?>
								</tbody>
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
<!-- User List End -->

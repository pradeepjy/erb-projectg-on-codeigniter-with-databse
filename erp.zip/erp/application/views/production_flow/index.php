<!-- User List Start -->
<div class="content-wrapper">
	<section class="content-header">
	    <div class="header-icon">
	        <i class="pe-7s-note2"></i>
	    </div>
	    <div class="header-title">
	        <h1><?php echo display('manage_production_flow') ?></h1>
	        <small><?php echo display('manage_production_flow') ?></small>
	        <ol class="breadcrumb">
	            <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
	            <li class="active"><?php echo display('manage_production_flow') ?></li>
	        </ol>
	    </div>
	</section>

	<section class="content">
		<!-- Alert Message -->
	    <?php
	        $message = $this->session->userdata('message');
	        if (isset($message)) {
	    ?>
	    <div class="alert alert-info alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('message');
	        }
	        $error_message = $this->session->userdata('error_message');
	        if (isset($error_message)) {
	    ?>
	    <div class="alert alert-danger alert-dismissable">
	        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
	        <?php echo $error_message ?>                    
	    </div>
	    <?php 
	        $this->session->unset_userdata('error_message');
	        }
	    ?>

	     <div class="row">
            <div class="col-sm-12">
                  <?php if($this->permission1->method('add_production_flow','create')->access()){?>
                  <a href="<?php echo base_url('production_flow/create')?>" class="btn btn-success m-b-5 m-r-2"><i class="ti-plus"></i>production Flow </a>
              <?php }?>
            </div>
        </div>
		<!-- production_flow List -->
		<div class="row">
		    <div class="col-sm-12">
		        <div class="panel panel-bd lobidrag">
		            <div class="panel-heading">
		                <div class="panel-title">
		                    <h4><?php echo display('production_flow') ?> </h4>
		                </div>
		            </div>
		            <div class="panel-body">
		                <div class="table-responsive">
		                    <table id="dataTableExample3" class="table table-bordered table-striped table-hover">
		           				<thead>
									<tr>
										<th><?php echo display('sl') ?></th>
										<th>Work Start Date</th>
										<th>Work End Date</th>
										<th>Wastage</th>
										<th>Total Expense</th>
										<th>Machine Used</th>
										<th>Queries That Raised</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php
                                
								if ($production_flow_list) {
									foreach ($production_flow_list as $production_flow) {
								?>
									<tr>
										<td><?php echo $production_flow["id"]?></td>
										<td><?php echo html_escape($production_flow["work_start_date"])?></td>
										<td><?php echo html_escape($production_flow["work_end_date"])?></td>
                                        <td><?php echo html_escape($production_flow["wastage"])?></td>
                                        <td><?php echo html_escape($production_flow["total_expense"])?></td>
										<td><?php echo html_escape($production_flow["machine_used"])?></td>
										<td><?php echo html_escape($production_flow["queries_that_raised"])?></td>
										<td>
											<center>
											<?php echo form_open()?>
												<a href="<?php echo base_url('production_flow/edit/'.$production_flow["id"]); ?>" class="btn btn-info btn-sm" data-toggle="tooltip" data-placement="left" title="" data-original-title="<?php echo display('update') ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
												
												<a href="<?php echo base_url('production_flow/delete/'.$production_flow["id"])?>" class="btn btn-danger btn-sm"  data-toggle="tooltip" onclick="return confirm('Are you Sure ?')" data-placement="right" title="" data-original-title="<?php echo display('delete') ?> "><i class="fa fa-trash-o" aria-hidden="true"></i></a>
												
											<?php echo form_close()?>
											</center>
										</td>
									</tr>
								<?php } } ?>
								</tbody>
		                    </table>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
</div>
<!-- User List End -->

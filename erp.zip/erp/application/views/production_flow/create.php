<!-- Add User start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1>production_flow</h1>
            <small>Add New production Flow</small>
            <ol class="breadcrumb">
                <li><a href="index.html"><i class="pe-7s-home"></i> Home</a></li>
                <li class="active">Add production Flow</li>
            </ol>
        </div>
    </section>

    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>
        <div class="row">
            <div class="col-sm-12">
                <?php if($this->permission1->method('production_flow','read')->access()){?>
                  <a href="#" class="btn btn-success m-b-5 m-r-2"><i class="ti-align-justify"></i>production Flow</a>
              <?php }?>
            </div>
        </div>
        <!-- New user -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('add_production_flow') ?> </h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('production_flow/store',array('class' => 'form-vertical','id'=>'validate'))?>
                    <div class="panel-body">
                        <div class="form-group row">
                            <label for="work_start_date" class="col-sm-3 col-form-label">Work Start Date</label>
                            <div class="col-sm-6">
                            <input type="text" class="datepicker form-control" name="work_start_date" placeholder="Work Start Date" id="work_start_date">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="work_end_date" class="col-sm-3 col-form-label">Work End Date</label>
                            <div class="col-sm-6">
                            <input type="text" class="datepicker form-control" name="work_end_date" placeholder="Work End Date" id="work_end_date">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="total_expense" class="col-sm-3 col-form-label">Total Expense<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="total_expense" id="wastage" placeholder="total_expense" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="machine_used" class="col-sm-3 col-form-label">Wastage<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="machine_used" id="machine_used" placeholder="Machine Used" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="wastage" class="col-sm-3 col-form-label">Wastage<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="wastage" id="wastage" placeholder="Wastage" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="queries_that_raised " class="col-sm-3 col-form-label">Quaries That Raised</label>
                            <div class="col-sm-6">
                                <textarea class="form-control" name="queries_that_raised" id="queries_that_raised " rows="3" placeholder="<?php echo display('queries_that_raised') ?>" tabindex="4"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-production_flow" class="btn btn-primary btn-large" name="add-production_flow" value="<?php echo display('save') ?>" tabindex="6"/>

								<input type="submit" value="<?php echo display('save_and_add_another') ?>e" name="add-production_flow-another" class="btn btn-success" id="add-production_flow-another" tabindex="7">
                            </div>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Edit user end -->




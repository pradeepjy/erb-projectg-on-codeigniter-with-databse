<!-- Edit User start -->
<div class="content-wrapper">
    <section class="content-header">
        <div class="header-icon">
            <i class="pe-7s-note2"></i>
        </div>
        <div class="header-title">
            <h1><?php echo display('production_flow_edit') ?></h1>
            <small><?php echo display('production_flow_edit') ?></small>
            <ol class="breadcrumb">
                <li><a href="#"><i class="pe-7s-home"></i> <?php echo display('home') ?></a></li>
                <li class="active"><?php echo display('production_flow_edit') ?></li>
            </ol>
        </div>
    </section>
    <section class="content">
        <!-- Alert Message -->
        <?php
            $message = $this->session->userdata('message');
            if (isset($message)) {
        ?>
        <div class="alert alert-info alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('message');
            }
            $error_message = $this->session->userdata('error_message');
            if (isset($error_message)) {
        ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
            <?php echo $error_message ?>                    
        </div>
        <?php 
            $this->session->unset_userdata('error_message');
            }
        ?>

        <!-- New user -->
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="panel-title">
                            <h4><?php echo display('production_flow_edit') ?> </h4>
                        </div>
                    </div>
                    <?php echo form_open_multipart('production_flow/update',array('class' => 'form-vertical','id'=>'validate' ))?>
                    <div class="panel-body">
                    <div class="form-group row">
                            <label for="work_start_date" class="col-sm-3 col-form-label">Work Start Date</label>
                            <div class="col-sm-6">
                            <input type="text" class="datepicker form-control" name="work_start_date" placeholder="Work Start Date" id="work_start_date" value="<?php echo $work_start_date?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="work_end_date" class="col-sm-3 col-form-label">Work End Date</label>
                            <div class="col-sm-6">
                            <input type="text" class="datepicker form-control" name="work_end_date" placeholder="Work End Date" id="work_end_date" value="<?php echo $work_end_date?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="wastage" class="col-sm-3 col-form-label">Wastage<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="text" tabindex="1" class="form-control" name="wastage" id="wastage" placeholder="Wastage" value="<?php echo $wastage?>" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="total_expense" class="col-sm-3 col-form-label">Total Expense<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="number" tabindex="1" class="form-control" name="total_expense" id="wastage" value="<?php echo $total_expense?>" placeholder="total Expense" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="machine_used" class="col-sm-3 col-form-label">Machine Used<i class="text-danger">*</i></label>
                            <div class="col-sm-6">
                                <input type="number" tabindex="1" class="form-control" name="machine_used" id="machine_used" value="<?php echo $machine_used?>" placeholder="Machine Used" required />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="queries_that_raised" class="col-sm-3 col-form-label">Quaries That Raised</label>
                            <div class="col-sm-6">
                                <textarea class="form-control" name="queries_that_raised" id="queries_that_raised " rows="3" placeholder="<?php echo display('queries_that_raised') ?>"  tabindex="4"><?php echo $queries_that_raised?></textarea>
                            </div>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id?>" />
                        <div class="form-group row">
                            <label for="example-text-input" class="col-sm-4 col-form-label"></label>
                            <div class="col-sm-6">
                                <input type="submit" id="add-production_flow" class="btn btn-success btn-large" name="add-production_flow" value="<?php echo display('save_changes') ?>" tabindex="6"/>
                            </div>
                        </div>
                    </div>
                    <?php echo form_close()?>
                </div>
            </div>
        </div>
    </section>
</div>
<!-- Edit user end -->




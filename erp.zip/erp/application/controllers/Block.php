<?php 
if(!defined('BASEPATH'))
exit('No direct script access allowed');

class Block extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('Lblock');
        $this->load->library('auth');
        $this->load->library('session');
        $this->load->model('blocks');
    }

    public function index()
    {
        $content = $this->lblock->block_list();
    
        $this->template->full_admin_html_view($content);
    }

    public function create()
    {
        $content = $this->lblock->block_add_form();
        $this->template->full_admin_html_view($content);
    }

    public function store()
    {
        $data1 = array(
            'block_code' =>$this->input->post('block_code'),
            'block_id' => $this->input->post('block_id'),
            'manufacturing_date' => $this->input->post('manufacturing_date'),
            'total_expense' => $this->input->post('total_expense'),
            'block_failed' => $this->input->post('block_failed'),
            'block_left' => $this->input->post('block_left'),
            'block_sale' => $this->input->post('block_sale'),
            'roleid' => $this->session->userdata('roleid'),
            'user_id' =>$this->session->userdata('user_id'),
            'status' =>'1',
        );
        $this->db->insert('block', $data1);
        $this->session->set_userdata(array('message' => display('successfully_added')));
        if (isset($_POST['add-block'])) {
            redirect('block/index');
        } elseif (isset($_POST['add-block-another'])) {
            redirect(base_url('block/index'));
        }
    }
    
    public function edit($blockid)
    {
        $content = $this->lblock->retrieve_block_editdata($blockid);
        $this->template->full_admin_html_view($content);
    }
     // block Update
    public function update()
    {
        
        $id= $this->input->post('id',TRUE);
        $data = array(
            'block_code' => $this->input->post('block_code',TRUE),
            'block_id'       => $this->input->post('block_id',TRUE),
            'manufacturing_date' => $this->input->post('manufacturing_date',TRUE),
            'total_expense' => $this->input->post('total_expense',TRUE),
            'block_failed'  => $this->input->post('block_failed',TRUE),
            'block_left'   => $this->input->post('block_left',TRUE),
            'block_sale'   => $this->input->post('block_sale',TRUE),

        );
       
        $abc= $this->blocks->update_block($data,$id);
        $this->session->set_userdata(array('message' => display('successfully_updated')));
        redirect(base_url('block/index'));
    }

    public function delete($id)
    {
        $this->blocks->delete_block($id);
        $this->session->set_userdata(array('message' => display('successfully_delete')));
        redirect(base_url('block/index'));
    }
}
<?php 
if(!defined('BASEPATH'))
exit('No direct script access allowed');

class Wall extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('lwall');
        $this->load->library('auth');
        $this->load->library('session');
        $this->load->model('Walls');
    }

    public function index()
    {
        $content = $this->lwall->wall_list();
    
        $this->template->full_admin_html_view($content);
    }

    public function create()
    {
        $content = $this->lwall->wall_add_form();
        $this->template->full_admin_html_view($content);
    }

    public function store()
    {
       
        $data1 = array(
            'wall_code' =>$this->input->post('wall_code'),
            'wall_id' => $this->input->post('wall_id'),
            'manufacturing_date' => $this->input->post('manufacturing_date'),
            'total_expense' => $this->input->post('total_expense'),
            'number_of_block' => $this->input->post('number_of_block'),
            'block_failed' => $this->input->post('block_failed'),
            'block_left' => $this->input->post('block_left'),
            'roleid' => $this->session->userdata('roleid'),
            'user_id' =>$this->session->userdata('user_id'),
            'status' =>'1',
        );
        $this->db->insert('wall', $data1);
        $this->session->set_userdata(array('message' => display('successfully_added')));
        if (isset($_POST['add-wall'])) {
            redirect('wall/index');
        } elseif (isset($_POST['add-wall-another'])) {
            redirect(base_url('wall/index'));
        }
    }
    
    public function edit($wallid)
    {
        $content = $this->lwall->retrieve_wall_editdata($wallid);
        $this->template->full_admin_html_view($content);
    }
     // Wall Update
    public function update()
    {
        
        $id= $this->input->post('id',TRUE);
        $data = array(
            'wall_code' => $this->input->post('wall_code',TRUE),
            'wall_id'       => $this->input->post('wall_id',TRUE),
            'manufacturing_date' => $this->input->post('manufacturing_date',TRUE),
            'total_expense' => $this->input->post('total_expense',TRUE),
            'number_of_block' => $this->input->post('number_of_block',TRUE),
            'block_failed'  => $this->input->post('block_failed',TRUE),
            'block_left'   => $this->input->post('block_left',TRUE),
        );
       
        $abc= $this->Walls->update_wall($data,$id);
        $this->session->set_userdata(array('message' => display('successfully_updated')));
        redirect(base_url('Wall/index'));
    }

    public function delete($id)
    {
        $this->Walls->delete_wall($id);
        $this->session->set_userdata(array('message' => display('successfully_delete')));
        redirect(base_url('Wall/index'));
    }
}
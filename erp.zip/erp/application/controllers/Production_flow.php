<?php 
if(!defined('BASEPATH'))
exit('No direct script access allowed');

class Production_flow extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->library('Lproduction_flow');
        $this->load->library('auth');
        $this->load->library('session');
        $this->load->model('Production_flows');
    }

    public function index()
    {
        $content = $this->lproduction_flow->production_flow_list();
    
        $this->template->full_admin_html_view($content);
    }

    public function create()
    {
        $content = $this->lproduction_flow->production_flow_add_form();
        $this->template->full_admin_html_view($content);
    }

    public function store()
    {
        $data1 = array(
            'work_start_date' =>$this->input->post('work_start_date'),
            'work_end_date' => $this->input->post('work_end_date'),
            'wastage' => $this->input->post('wastage'),
            'total_expense' => $this->input->post('total_expense'),
            'machine_used' => $this->input->post('machine_used'),
            'queries_that_raised' => $this->input->post('queries_that_raised'),
            'roleid' => $this->session->userdata('roleid'),
            'user_id' =>$this->session->userdata('user_id'),
            'status' =>'1',
        );
        $this->db->insert('production_flow', $data1);
        $this->session->set_userdata(array('message' => display('successfully_added')));
        if (isset($_POST['add-production_flow'])) {
            redirect('production_flow/index');
        } elseif (isset($_POST['add-production_flow-another'])) {
            redirect(base_url('production_flow/index'));
        }
    }
    
    public function edit($production_flowid)
    {
        $content = $this->lproduction_flow->retrieve_production_flow_editdata($production_flowid);
        $this->template->full_admin_html_view($content);
    }
     // production_flow Update
    public function update()
    {
        
        $id= $this->input->post('id',TRUE);
        $data = array(
            'work_start_date' => $this->input->post('work_start_date',TRUE),
            'work_end_date'       => $this->input->post('work_end_date',TRUE),
            'wastage' => $this->input->post('wastage',TRUE),
            'total_expense' => $this->input->post('total_expense',TRUE),
            'machine_used'  => $this->input->post('machine_used',TRUE),
            'queries_that_raised'   => $this->input->post('queries_that_raised',TRUE),

        );
       
        $abc= $this->Production_flows->update_production_flow($data,$id);
        $this->session->set_userdata(array('message' => display('successfully_updated')));
        redirect(base_url('production_flow/index'));
    }

    public function delete($id)
    {
        $this->Production_flows->delete_production_flow($id);
        $this->session->set_userdata(array('message' => display('successfully_delete')));
        redirect(base_url('production_flow/index'));
    }
}
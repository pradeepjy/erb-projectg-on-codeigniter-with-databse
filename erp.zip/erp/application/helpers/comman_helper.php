<?php

defined('BASEPATH') OR exit('No direct script access allowed');

function userrole($id)
{
   
    $ci = & get_instance();
    $ci->load->database();
    $row = $ci->db->select('sec_role.type,sec_role.id')
    ->from('sec_userrole')
    ->where('user_id', $id)
    ->join('sec_role','sec_role.id=sec_userrole.roleid')
    ->get()
    ->row();
    return $row;

}
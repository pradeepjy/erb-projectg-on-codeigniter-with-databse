<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Blocks extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function block_list() {
        $this->db->select('*');
        $this->db->from('block');
        $this->db->where('roleid',$this->session->userdata('roleid') OR 'roleid','1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }  
    
    
    //Retrieve block Edit Data
    public function block_editdata($block_id) {
        $this->db->select('*');
        $this->db->from('block');
        $this->db->where('id', $block_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Update block   
    public function update_block($data, $blockid) {
        $this->db->where('id', $blockid);
        $this->db->update('block', $data);
        $this->db->select('*');
        $this->db->from('block');
        $this->db->where('status', 1);
        $query = $this->db->get();
        return true;
    }

    public function delete_block($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('block');
    }
}

    ?>

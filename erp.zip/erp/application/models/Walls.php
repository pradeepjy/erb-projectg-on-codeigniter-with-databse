<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Walls extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function wall_list() {
        $this->db->select('*');
        $this->db->from('wall');
        $this->db->where('roleid',$this->session->userdata('roleid') OR 'roleid','1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }  
    
    
    //Retrieve Wall Edit Data
    public function wall_editdata($wall_id) {
        $this->db->select('*');
        $this->db->from('wall');
        $this->db->where('id', $wall_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Update wall   
    public function update_wall($data, $wallid) {
        $this->db->where('id', $wallid);
        $this->db->update('wall', $data);
        $this->db->select('*');
        $this->db->from('wall');
        $this->db->where('status', 1);
        $query = $this->db->get();
        return true;
    }

    public function delete_wall($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('wall');
    }
}

    ?>

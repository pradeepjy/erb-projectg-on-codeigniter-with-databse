<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Production_flows extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function production_flow_list() {
        $this->db->select('*');
        $this->db->from('production_flow');
        $this->db->where('roleid',$this->session->userdata('roleid') OR 'roleid','1');
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }  
    
    
    //Retrieve production_flow Edit Data
    public function production_flow_editdata($production_flow_id) {
        $this->db->select('*');
        $this->db->from('production_flow');
        $this->db->where('id', $production_flow_id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->result_array();
        }
        return false;
    }

    //Update production_flow   
    public function update_production_flow($data, $production_flowid) {
        $this->db->where('id', $production_flowid);
        $this->db->update('production_flow', $data);
        $this->db->select('*');
        $this->db->from('production_flow');
        $this->db->where('status', 1);
        $query = $this->db->get();
        return true;
    }

    public function delete_production_flow($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('production_flow');
    }
}

    ?>
